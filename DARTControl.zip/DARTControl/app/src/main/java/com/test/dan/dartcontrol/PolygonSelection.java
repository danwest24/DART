package com.test.dan.dartcontrol;



import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;


public class PolygonSelection extends FragmentActivity implements OnMapReadyCallback {
    final List<Marker> markers = new ArrayList<Marker>();
    private GoogleMap mMap;
    private static final String TAG = "POLYGON_SELECTOR";
    private static final int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    private static final int DEFAULT_ZOOM = 15;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_polygon_selection);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        //Context context = getApplication().checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION);
        //LatLng latlng = getLocation();
        //Log.v(TAG, String.valueOf(latlng.longitude));
        //Log.v(TAG, String.valueOf(latlng.latitude));
        int permissionCheck = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_CALENDAR);
        Log.v(TAG, String.valueOf(permissionCheck));
        if(permissionCheck == -1){
            // Here, thisActivity is the current activity

            Log.v(TAG, "permission not granted - get permission");
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                Log.v(TAG, "Request permission explanation");
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }

        Button button = (Button) findViewById(R.id.button3);
        button.setBackgroundColor(getResources().getColor(R.color.heliosGrey));
        button.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {

                goToFourthActivity(markers);

            }
        });

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //request granted
                    Log.v(TAG, "request granted");
                    LatLng latlng = getLocation();
                    Log.v(TAG, String.format("Current Latitude: %1$s",latlng.latitude));
                    Log.v(TAG, String.format("Current Longitude: %1$s",latlng.longitude));
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latlng.latitude, latlng.longitude), DEFAULT_ZOOM));


                } else {
                    Log.v(TAG, "request denied");

                }
                return;
            }


            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    private void goToFourthActivity(final List<Marker> markers) {

        Intent intent = new Intent(getApplicationContext(), Send_info.class);
        //String getrec=textView.getText().toString();
        int sizeM = markers.size();
        for (int i = 0; i < sizeM; i++) {
            intent.putExtra(String.format("GPSlat%1$s", i), String.valueOf(markers.get(i).getPosition().latitude));
            intent.putExtra(String.format("GPSlong%1$s", i), String.valueOf(markers.get(i).getPosition().longitude));
        }

        startActivity(intent);

    }

    public LatLng getLocation() {
        // Get the location manager
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        String bestProvider = locationManager.getBestProvider(criteria, false);
        Location location = locationManager.getLastKnownLocation(bestProvider);
        Double lat, lon;
        try {
            lat = location.getLatitude();
            lon = location.getLongitude();
            return new LatLng(lat, lon);
        } catch (NullPointerException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        try {
            mMap.setMyLocationEnabled(true);
        } catch (SecurityException sec) {
            Log.w(TAG, "Location Denied");
        }
        mMap.getUiSettings().setMyLocationButtonEnabled(true);
        mMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {
                //mMap.addMarker(new MarkerOptions()
                //        .position(latLng)
                //        .title("Your marker title")
                //         .snippet("Your marker snippet"));
                int sizeM = markers.size();
                Button mButton = (Button) findViewById(R.id.button3);
                mButton.setBackgroundColor(getResources().getColor(R.color.heliosGrey));
                mButton.setEnabled(false);
                Marker m = mMap.addMarker(new MarkerOptions()
                        .position(latLng)
                        .title(String.format("Point %1$s", String.valueOf(sizeM))));
                markers.add(m);
                sizeM = markers.size();
                if ((sizeM > 0) && (sizeM < 3)){
                    mButton.setText(String.format("Select at least %1$s more points", String.valueOf(3-sizeM)));

                }
                if (sizeM > 2) {
                    mButton.setEnabled(true);
                    mButton.setText(String.format("Close Polygon with %1$s Points", String.valueOf(sizeM)));
                    mButton.setBackgroundColor(getResources().getColor(R.color.heliosRed));
                }
                for (int i = 1; i < sizeM; i++) {


                    PolylineOptions line = new PolylineOptions().add(markers.get(i).getPosition(),markers.get(i-1).getPosition()).width(5).color(Color.BLUE);
                    mMap.addPolyline(line);
                }


            }

        });

    }

    private void drawMarker(Location location) {
        if (mMap != null) {
            mMap.clear();
            LatLng gps = new LatLng(location.getLatitude(), location.getLongitude());
            mMap.addMarker(new MarkerOptions()
                    .position(gps)
                    .title("Current Position"));
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(gps, 12));
        }
    }
}
