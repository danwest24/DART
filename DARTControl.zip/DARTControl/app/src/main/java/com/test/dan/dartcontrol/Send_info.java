package com.test.dan.dartcontrol;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PointF;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.android.gms.maps.model.Marker;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import android.graphics.Point;

import static java.lang.Math.abs;

public class Send_info extends AppCompatActivity {
    final List<Marker> markers = new ArrayList<Marker>();
    final static int REQUEST_ENABLE_BT = 2;
    TableLayout tableLayout;
    TableRow newTR;            // variable declare for dynamic table row
    TextView newTxtlat, newTxtlong;
    private static final String TAG = "GPS_SEND";
    private ByteBuffer localByteBuffer;
    private InputStream in;
    byte[] arrayOfByte = new byte[4096];
    int bytes;
    public BluetoothDevice mDevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //DecimalFormat df = new DecimalFormat("##.##");
        //df.setRoundingMode(RoundingMode.DOWN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_info);
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();


        if (mBluetoothAdapter == null) {
            // Device does not support Bluetooth
            Log.v(TAG, "DEVICE DOES NOT SUPPORT BLUETOOTH");
        }
        else{
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();

                if (pairedDevices.size() > 0) {
                    // There are paired devices. Get the name and address of each paired device.
                    for (BluetoothDevice device : pairedDevices) {
                        String deviceName = device.getName();
                        String deviceHardwareAddress = device.getAddress(); // MAC address
                        Log.v(TAG, deviceName);
                        Log.v(TAG, deviceHardwareAddress);
                    }
                }
            }
        }
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        setup();
        Intent intent = getIntent();
        Bundle GPSPoints = intent.getExtras();

        int sizeM = 0;
        if (GPSPoints != null) {
            sizeM = GPSPoints.size()/2;
        }

        List<String> latitudes = new ArrayList<String>();
        List<String> longitudes = new ArrayList<String>();
        final List<PointD> pList = new ArrayList<PointD>();
        List<Line> lineList = new ArrayList<Line>();
        for (int i = 0; i < sizeM; i++) {


            if (GPSPoints != null) {
                String latit = intent.getStringExtra(String.format("GPSlat%1$d", i));
                String longit = intent.getStringExtra(String.format("GPSlong%1$d", i));
                latitudes.add(latit);
                longitudes.add(longit);
                PointD point = new PointD();

                double tempx = Double.parseDouble(longitudes.get(i));
                long aux = (long)(tempx*1000000);//1243
                point.x = aux/1000000d;//12.43
                double tempy = Double.parseDouble(latitudes.get(i));
                long auxy = (long)(tempy*1000000);//1243
                point.y = auxy/1000000d;//12.43
                pList.add(point);
            }
        }
        double A = 0;
        // List<Float> inter = new ArrayList<Float>();
        for (int i = 0; i < sizeM; i++) {

            int i2 = i+1;
            if (i2 >= sizeM) {
                i2 = 0;
            }
            Log.v(TAG, String.format("%1$f", pList.get(i).y));
            Line line = new Line(pList.get(i), pList.get(i2));
            lineList.add(line);
            //Log.v(TAG, String.format("%9.8f",pList.get(i).x));

            A += ((pList.get(i).x *pList.get(i2).y) - (pList.get(i2).x*pList.get(i).y))*(111*111);



        }

        ArrayList<ArrayList<Double>> intersections = new ArrayList<ArrayList<Double>>();

        int sizelineList = lineList.size();
        for (int i1 = 0; i1< sizelineList; i1++){
            ArrayList<Double> newIntersections = new ArrayList<Double>();
            for(int i2 = 0; i2<sizelineList; i2++){
                Line l1 = lineList.get(i2);
                Line l2 = lineList.get(i1);
                ArrayList<Double> inters = intersection(l1, l2);
                intersections.add(inters);
                //Log.v(TAG, String.format("%1$f", l1.p1.x));
                Log.v(TAG, String.format("%1$f output x", inters.get(0)));
                Log.v(TAG, String.format("%1$f output y", inters.get(1)));
            }
        }
        boolean validFlag = true;
        for (int i = 0; i < intersections.size(); i++) {
            if (!(intersections.get(i).get(0) == 0f)){
                validFlag = false;
            }
        }

        Button button = (Button) findViewById(R.id.button4);
        if (validFlag == false){
            button.setEnabled(false);
            button.setBackgroundColor(getResources().getColor(R.color.heliosGrey));
            button.setText(String.format("Invalid Polygon", String.valueOf(sizeM)));
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                transmitInfo(pList);
            }
        });

        TextView texty = (TextView) findViewById(R.id.textView8);

        A = abs(A/2);
        texty.setText(String.format("Polygon Area: %1$f km^2",A));
        Log.v(TAG,"LineList created");
        Log.v(TAG, String.format("Polygon Area: %1$f km^2",A));

        tableLayout = (TableLayout) findViewById(R.id.tblLayout); // table layout typecasting...
        tableLayout.setColumnStretchable(0, true); //first column
        tableLayout.setColumnStretchable(1, true); //second column
        tableLayout.setColumnStretchable(2, true);

        dynamicViewElement(latitudes, longitudes);
    }



    public void transmitInfo(List<PointD> pList){
        Log.v(TAG, "transmit");
        BluetoothDevice zee = BluetoothAdapter.getDefaultAdapter().
                getRemoteDevice("B8:27:EB:59:7F:41");// add device mac adress

        try {
            sock = zee.createRfcommSocketToServiceRecord(
                    UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")); // use unique UUID
        } catch (IOException e1) {
            Log.e(TAG, e1.toString());
        }

        Log.d(TAG, "++++ Connecting");


        EditText eText = (EditText) findViewById(R.id.editText);
        Log.v("EditText", eText.getText().toString());

        ByteArrayOutputStream out = new ByteArrayOutputStream();



        for (PointD item : pList) {
            out.write((byte)'X');
            String tempx = new BigDecimal(item.x).toPlainString();
            String tempy = new BigDecimal(item.y).toPlainString();
            for (int i = 0; i< 11; i++){
                out.write((byte)tempx.charAt(i));
            }
            out.write((byte)'Y');
            for (int i = 0; i < 11; i++){
                out.write((byte)tempy.charAt(i));
            }


        }
        out.write((byte)'E');
        for (int i = 0; i<eText.getText().toString().length(); i++){
            out.write((byte)eText.getText().toString().charAt(i));
        }
        out.write((byte)'D');
        byte[] arr_combined = out.toByteArray();
        try {
            sock.connect();
            Log.d(TAG, "Connected to RF socket");
            Log.d(TAG, "writing to socket...");
            sock.getOutputStream().write(arr_combined);
            Log.d(TAG, "Write Complete -- closing socket");
            try {
                //set time in mili
                Thread.sleep(1000);

            }catch (Exception e){
                e.printStackTrace();
            }
            sock.close();
            Log.d(TAG, "closed socket");
        } catch (IOException e1) {
            Log.e(TAG, e1.toString());
        }



    }
    private static final LogBroadcastReceiver receiver = new LogBroadcastReceiver();
    public static class LogBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent) {
            Log.d("Receiver", paramAnonymousIntent.toString());
            Bundle extras = paramAnonymousIntent.getExtras();
            for (String k : extras.keySet()) {
                Log.d("Receiver", "    Extra: "+ extras.get(k).toString());
            }
        }


    };

    private BluetoothSocket sock;

    @Override
    public void onDestroy() {
        getApplicationContext().unregisterReceiver(receiver);
        if (sock != null) {
            try {
                sock.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        super.onDestroy();
    }

    private void setup() {

        getApplicationContext().registerReceiver(receiver,
                new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED));
        getApplicationContext().registerReceiver(receiver,
                new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED));
    }

    public void dynamicViewElement(List<String> latit, List<String> longit) {
        int sizeP = latit.size();
        //Log.v(TAG, "index=" + sizeP);
        for (int i = 0; i < sizeP; i++) {

            TextView newTxtind = new TextView(Send_info.this);
            newTxtlat = new TextView(Send_info.this);
            newTxtlong = new TextView(Send_info.this);
            newTxtlat.setText(String.format("%12.9s", latit.get(i)));
            newTxtlong.setText(String.format("%12.9s", longit.get(i)));
            newTxtind.setText(String.valueOf(i));


            if (newTxtlat != null) {
                newTR = new TableRow(Send_info.this);
                newTR.addView(newTxtind);
                newTR.addView(newTxtlat);
                newTR.addView(newTxtlong);
                tableLayout.addView(newTR);
            }


        }

    }

    public ArrayList<Double> intersection(Line line1, Line line2){
        //intersection takes an input of two Line types (custom, see below class). The output is an
        // arraylist containing either an intersection coordinate, or 0. (in python version, object uses
        //both floats for the intersection and boolean false for no intersection)

        //Determinants for Cramer's method
        double D = (line1.A*line2.B - line1.B*line2.A);
        double Dx = (line1.C*line2.B - line1.B*line2.C);
        double Dy = (line1.A*line2.C - line1.C*line2.A);
        //inter is an array to hold the intersection coordinates. (or 0 if none)
        ArrayList<Double> inter = new ArrayList<Double>();
        //ensure D is not zero or very close to zero (due to float error) so as not to divide by zero
        Log.v(TAG, String.format("%12.9f D", D));
        if (!((D < 0.000001d) && (D > -0.000001d))){
            //Log.v(TAG, String.format("%12.9f D", D));
            double x = (Dx/D);
            double y = (Dy/D);
            Log.v(TAG, String.format("%12.9f xcoord intersection", x));
            Log.v(TAG, String.format("%12.9f ycoord intersection", y));
            //bounds checking ensures that not is there an intersection between the lines, but there is
            //between the segments as well.
            //arg 1  - max of line1 x's means point farthest to the right of line1
            //arg 2 - min of line2 x's means point farthest to left of line2
            // if no segment overlap in x, then no intersection. point farthest to right of line1 must
            //be somewhere between the two points in the other line
            //arg1 < arg2 for this to occur
            if (Math.max(line1.p1.x, line1.p2.x) < Math.min(line2.p1.x,line2.p2.x)){

                Log.v(TAG, "no segment overlap x");
                Log.v(TAG, String.format("%13.10f",(Math.max(line1.p1.x, line1.p2.x))));
                Log.v(TAG, String.format("%13.10f",(Math.min(line2.p1.x,line2.p2.x))));
                x = 0;
                y = 0;
                inter.add(x);
                inter.add(y);

                return inter;
            }
            //same as above, but for y
            if (Math.max(line1.p1.y, line1.p2.y) < Math.min(line2.p1.y,line2.p2.y)){
                Log.v(TAG, "no segment overlap y");
                //max l1< min l2
                Log.v(TAG, String.format("%13.10f",(Math.max(line1.p1.y, line1.p2.y))));
                Log.v(TAG, String.format("%13.10f",(Math.min(line2.p1.y,line2.p2.y))));
                x = 0;
                y = 0;

                inter.add(x);
                inter.add(y);

                return inter;
            }
            //if ((x < max( min(L1[3][0],L1[4][0]), min(L2[3][0],L2[4][0]))) or (x > min( max(L1[3][0],L1[4][0]), max(L2[3][0],L2[4][0]) )))

            if ((x < (Math.max(Math.min(line1.p1.x,line1.p2.x), Math.min(line2.p1.x,line2.p2.x)))) || (x > (Math.min(Math.max(line1.p1.x, line1.p2.x), Math.max(line2.p1.x, line2.p2.x))))){
                Log.v(TAG, "no shared segment overlap x");
                // top > mid > bottom
                Log.v(TAG, String.format("%13.10f", Math.min(Math.max(line1.p1.x, line1.p2.x), Math.max(line2.p1.x, line2.p2.x))));
                Log.v(TAG, String.format("%13.10f", x));
                Log.v(TAG, String.format("%13.10f", Math.max(Math.min(line1.p1.x,line1.p2.x), Math.min(line2.p1.x,line2.p2.x))));

                x = 0;
                y = 0;

                inter.add(x);
                inter.add(y);

                return inter;
            }
            if ((y < Math.max(Math.min(line1.p1.y,line1.p2.y), Math.min(line2.p1.y,line2.p2.y))) || (y > Math.min(Math.max(line1.p1.y, line1.p2.y), Math.max(line2.p1.y, line2.p2.y)))){
                Log.v(TAG, "no shared segment overlap y");
                Log.v(TAG, String.format("%13.10f", Math.min(Math.max(line1.p1.y, line1.p2.y), Math.max(line2.p1.y, line2.p2.y))));
                Log.v(TAG, String.format("%13.10f", x));
                Log.v(TAG, String.format("%13.10f", Math.max(Math.min(line1.p1.y,line1.p2.y), Math.min(line2.p1.y,line2.p2.y))));
                x = 0;
                y = 0;

                inter.add(x);
                inter.add(y);

                return inter;
            }



            inter.add(x);
            inter.add(y);
            Log.v(TAG, "should have coordinates");
            return inter;


        }
        else {

            double x = 0;
            double y = 0;
            inter.add(x);
            inter.add(y);
            Log.v(TAG, "divide by zero");
            return inter;

        }


    }
    public class Line{
        //Class for storage of the parameters A, B, and C (used to make determinants easier) as well as
        // the two points as PointF type.
        private Double A;
        private Double B;
        private Double C;
        public PointD p1;
        public PointD p2;
        public Line(PointD point1, PointD point2){

            p1 = point1;
            p2 = point2;
            A = (p1.y - p2.y);
            B = (p2.x - p1.x);
            C = -(p1.x*p2.y - p2.x*p1.y);
        }
    }
    public class PointD{
        public double x;
        public double y;
        //public PointD(double xIn, double yIn){
        //    x = xIn;
        //    y = yIn;
        //}
    }


}